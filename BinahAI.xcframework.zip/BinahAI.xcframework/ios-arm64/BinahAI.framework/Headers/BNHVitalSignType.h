//
//  BNHVitalSignType.h
//  BinahAI
//
//  Created by Tal Lerman on 22/02/2023.
//

#ifndef VitalSignType_h
#define VitalSignType_h

typedef int64_t BNHVitalSignType NS_SWIFT_NAME(VitalSignType);

#endif /* VitalSignType_h */
